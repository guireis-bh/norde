<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ScheduleStudant extends Model
{
    protected $table = 'schedules_studants';
}
